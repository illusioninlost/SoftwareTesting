package com.richardchang;

/**
 * @author richard chang
 * @date 7/31/22
 */
import java.util.*;

public class Appointment {

	// fields
	private String appointmentId;
	private Date appointmentDate;
	private String description;

	// constructor
	public Appointment(String appointmentId, Date appointmentDate, String description) {

		// validate appointment id
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid appointment id - null or length > 10");
		}

		// checks date
		if (appointmentDate == null) {
			throw new IllegalArgumentException("Invalid appointment date - null");
		}
		if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid appointment date -past date");
		}

		// checks description
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description - null or length > 50");
		}

		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}

	// getters and setters
	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
