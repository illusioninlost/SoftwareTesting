package com.richardchang;

/*
 * @Author:Richard CHang
 * @Date: 7/12/22
 */

public class Contact {
	
	private String contactId; // length <= 10
	private String firstName; // length <= 10
	private String lastName; // length <= 10
	private String phoneNumber; // length <= 10
	private String address; // length <= 30
	
	//constructor
	public Contact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid contact ID - null or length > 10");
		}
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name - null or length > 10");
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name - null or length > 10");
		}
		if (phoneNumber == null || phoneNumber.length() > 10) {
			throw new IllegalArgumentException("Invalid phone number - null or length > 10");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address - null or length > 30");
		}

	
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	//getter methods for fields
	public String getContactId() {
		return this.contactId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public String getAddress() {
		return this.address;
	}


	//setter methods for fields
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setAddress(String address) {
		this.address = address;
	}


}
