package com.richardchang;

/**
 * @author richard chang
 * @date 7/31/22
 */

import java.util.*;

public class AppointmentService {

	private List<Appointment> appointmentList = new ArrayList<>();

	public boolean addAppointment(String newId, Date newAppointmentDate, String newDescription) {

		boolean checkAppointment = false;
		// loop through appointments
		for (Appointment a : appointmentList) {
			if (a.getAppointmentId().equals(newId)) {
				checkAppointment = true;
				System.out.println("Appointment id exists. No appointment added.");
				return false;
			}
		}

		// add task
		Appointment appt = new Appointment(newId, newAppointmentDate, newDescription);
		appointmentList.add(appt);
		System.out.println("Appointment added.");
		return true;
	}

	public boolean deleteAppointment(String id) {
		boolean checkAppointment = false;
		// loop through appointments
		for (Appointment a : appointmentList) {
			if (a.getAppointmentId().equals(id)) {
				checkAppointment = true;
				System.out.print(a + "removed from appointments.");
				appointmentList.remove(a);
				return true;
			}
		}

		System.out.println("No appointment deleted. Id does not exist.");
		return false;
	}
}
