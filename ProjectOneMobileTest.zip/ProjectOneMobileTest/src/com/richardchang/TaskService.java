package com.richardchang;

import java.util.ArrayList;
import java.util.List;

import com.richardchang.Task;

/**
 * 
 * @author Richard Chang
 * @date 7/20/22
 *
 */

public class TaskService {

	private List<Task> taskList = new ArrayList<>();

	// constructor
	public TaskService() {
		taskList = new ArrayList<>();
	}

	// add task
	public boolean addTask(String taskId, String name, String description) {

		boolean checkTask = false;
		// loop through tasks
		for (Task t : taskList) {
			if (t.getTaskId().equals(taskId)) {
				checkTask = true;
				return false;
			}
		}

		// add task
		Task task = new Task(taskId, name, description);
		taskList.add(task);
		System.out.println("Task added.");
		return true;
	}

	// delete task
	public boolean deleteTask(String taskId) {

		boolean checkTask = false;
		// loop through tasks
		for (Task t : taskList) {
			if (t.getTaskId().equals(taskId)) {
				checkTask = true;
				// delete task
				taskList.remove(t);
				System.out.println("Task removed.");
				return true;

			}
		}

		return false;
	}

	// update task list
	public boolean updateTask(String taskId, String name, String description) {
		// loop through tasks
		for (Task t : taskList) {
			// match task id
			if (t.getTaskId().equals(taskId)) {
				// check and update name
				if (name != null && (!name.equals("")) && !(name.length() > 20)) {
					t.setName(name);
				}
				// check and update description
				if (description != null && (!description.equals("")) && !(description.length() > 50)) {
					t.setDescription(description);
				}

				System.out.println("Task updated.Not updated field if parameters do not meet requirements.");
				return true;
			}
		}
		System.out.println("No task updated.");
		return false;
	}
}
