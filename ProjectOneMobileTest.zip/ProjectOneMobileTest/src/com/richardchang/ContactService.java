package com.richardchang;

/*
 * @Author:Richard CHang
 * @Date: 7/12/22
 */

import java.util.*;

public class ContactService {
	private List<Contact> contacts;
	
	//constructor
	public ContactService() {
		contacts = new ArrayList<>();
	}

	//add contact
	public boolean addContact(Contact contact) {
		
		boolean checkContact = false;
		//loop through contacts
		for(Contact c: contacts) {
			if(c.getContactId().equals(contact.getContactId())){
				checkContact = true;
				return false;
			}
		}
		
		//add contact
		contacts.add(contact);
		System.out.println("Contact added.");
		return true;
	}

	//delete contact
	public boolean deleteContact(String contactId) {
		
		boolean checkContact = false;
		//loop through contacts
		for(Contact c: contacts) {
			if(c.getContactId().equals(contactId)){
				checkContact = true;
				//delete contact
				contacts.remove(c);
				System.out.println("Contact removed.");
				return true;
			
			}
		}
		
		return false;
	}

	//update contact list
	public boolean updateContact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
		//loop through contacts
		for (Contact c: contacts) {
			//match contact id
			if (c.getContactId().equals(contactId)) {
				//check and update first name
				if (firstName != null && (!firstName.equals("")) && !(firstName.length() > 10)) {
					c.setFirstName(firstName);
				}
				//check and update last name
				if (lastName != null && (!lastName.equals("")) && !(lastName.length() > 10)) {
					c.setLastName(lastName);
				}
				//check and update phone number
				if (phoneNumber != null && (!phoneNumber.equals("")) && !(phoneNumber.length() > 10)) {
					c.setPhoneNumber(phoneNumber);
				}
				//check and update address
				if (address != null && (!address.equals("")) && !(address.length() > 30)) {
					c.setAddress(address);
				}
				System.out.println("Contact updated.Not updated field if parameters do not meet requirements.");
				return true;
			} 
		} 
		System.out.println("No contact updated.");
		return false;
	}
	
} 