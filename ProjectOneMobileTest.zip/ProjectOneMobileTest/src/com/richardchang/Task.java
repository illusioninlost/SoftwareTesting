
package com.richardchang;

/**
 * 
 * @author Richard
 * @date 7/20/22
 *
 */
public class Task {

	// fields
	private String taskId;
	private String name;
	private String description;

	// constructor
	public Task(String taskId, String name, String description) {

		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid task id - null or length > 10");
		}

		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name - null or length > 20");
		}

		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description - null or length > 50");
		}

		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}

	// getters
	public String getTaskId() {
		return taskId;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	// setters
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name - null or length > 20");
		} else {
			this.name = name;
		}
	}

	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description - null or length > 50");
		} else {
			this.description = description;
		}
	}
}
