package test;
/**
 * @author richard chang
 * @date 7/31/22
 */
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import static org.junit.Assert.assertEquals;


import com.richardchang.AppointmentService;

public class AppointmentServiceTest {
	
	@Test
	public void testAddAppointment() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		
		AppointmentService as = new AppointmentService();
		boolean checkTest = as.addAppointment("2", currentDatePlusOne, "doctor");
		assertEquals(true, checkTest);
	}

	@Test
	public void testAddAppointmentFail() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		
		AppointmentService as = new AppointmentService();
		as.addAppointment("2", currentDatePlusOne, "doctor");
		boolean checkTest = as.addAppointment("2", currentDatePlusOne, "doctor");
		assertEquals(false, checkTest);
	}
	
	
	@Test
	public void testRemoveAppointment() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		
		AppointmentService as = new AppointmentService();
		as.addAppointment("2", currentDatePlusOne, "doctor");
		boolean checkTest = as.deleteAppointment("2");
		assertEquals(true, checkTest);
	}
	
	@Test
	public void testRemoveAppointmentFail() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		
		AppointmentService as = new AppointmentService();
		boolean checkTest = as.deleteAppointment("2");
		assertEquals(false, checkTest);
	}
}
