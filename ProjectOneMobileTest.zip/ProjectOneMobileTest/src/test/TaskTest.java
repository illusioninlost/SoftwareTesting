package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.richardchang.Task;

/**
 * 
 * @author Richard
 * @date 7/20/22
 *
 */
public class TaskTest {
	@Test
	public void testTaskConstructor() {
		Task t = new Task("1233", "new name", "new description");
		assertEquals("1233", t.getTaskId());
		assertEquals("new name", t.getName());
		assertEquals("new description", t.getDescription());
	}

	@Test
	public void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1233w563465345654665465546", "new name", "new description");
		});
	}

	@Test
	public void testTaskIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "new name", "new description");
		});
	}

	@Test
	public void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "new nameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "new description");
		});
	}

	@Test
	public void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", null, "new description");
		});
	}

	@Test
	public void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "new name",
					"new descriptionnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"
					+ "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"
					+ "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"
					+ "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		});
	}

	@Test
	public void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "new name", null);
		});
	}

}
