package test;

/*
 * @Author:Richard CHang
 * @Date: 7/12/22
 */
import static org.junit.jupiter.api.Assertions.*;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

import com.richardchang.Contact;
import com.richardchang.ContactService;

class ContactServiceTest {
	
	//test addContact() method
	@Test
	void testAddContact() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		assertEquals(true, cs.addContact(contact1));
	}

	@Test
	void testAddContactFail() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		Contact contact2 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		cs.addContact(contact1);
		assertEquals(false, cs.addContact(contact2));
	}

	//test deleteContact() method
	@Test
	void testDeleteContact() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		Contact contact2 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		cs.addContact(contact1);
		assertEquals(true, cs.deleteContact("1234567890"));
	}

	@Test
	void testDeleteContactFail() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		Contact contact2 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		cs.addContact(contact1);
		assertEquals(false, cs.deleteContact("123456"));
	}
	
	//test updateContact() method
	@Test
	void testUpdateContact() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		cs.addContact(contact1);
		assertEquals(true, cs.updateContact("1234567890", "NewBat", "NewMan", "12345", "234 Main"));
	}

	@Test
	void testUpdateContactFail() {
		ContactService cs = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bat", "Man", "1234567890", "234 Main St");
		cs.addContact(contact1);
		assertEquals(false, cs.updateContact("12340", "NewBat", "NewMan", "12345", "234 Main"));
	}

}
