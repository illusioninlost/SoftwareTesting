package test;

/*
 * @Author:Richard CHang
 * @Date: 7/12/22
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.richardchang.Appointment;
import com.richardchang.Contact;

class ContactTest {
	
	@Test
	public void testContactConstructor() {
		Contact c = new Contact("123456789", "Bat", "Man", "1234567890", "234 Main St");
		assertEquals("123456789", c.getContactId());
		assertEquals("Bat", c.getFirstName());
		assertEquals("Man", c.getLastName());
		assertEquals("1234567890", c.getPhoneNumber());
		assertEquals("234 Main St", c.getAddress());

	}

	// test ContactId
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678900000000", "Bat", "Man", "1234567890", "234 Main St");
		});
	}

	@Test
	void testContactIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Bat", "Man", "1234567890", "234 Main St");
		});
	}

	// test firstName
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Battttttttttttt", "Man", "1234567890", "234 Main St");
		});
	}

	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", null, "Man", "1234567890", "234 Main St");
		});
	}

	// test lastName
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", "Mannnnnnnnnnnnnnnnn", "1234567890", "234 Main St");
		});
	}

	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", null, "1234567890", "234 Main St");
		});
	}

	// testPhoneNumber
	@Test
	void testPhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", "Man", "123456789000000000000000000", "234 Main St");
		});
	}

	@Test
	void testPhoneNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", "Man", null, "234 Main St");
		});
	}

	// test address
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", "Man", "123456789", "234 Main Sttttttttttttttttttttttttttttttttttttttt");
		});
	}

	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bat", "Man", "123456789", null);
		});
	}
}
