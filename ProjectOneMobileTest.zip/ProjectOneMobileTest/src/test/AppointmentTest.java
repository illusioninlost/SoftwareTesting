package test;

/**
 * @author richard chang
 * @date 7/31/22
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.junit.jupiter.api.Test;

import com.richardchang.Appointment;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
	private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	@Test
	public void testAppointmentConstructor() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		Appointment appt = new Appointment("1", currentDatePlusOne, "dentist");
		assertEquals("1", appt.getAppointmentId());
		assertEquals(currentDatePlusOne, appt.getAppointmentDate());
		assertEquals("dentist", appt.getDescription());
	}

	@Test
	public void testAppointmentIdLength() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();
		assertThrows(IllegalArgumentException.class,
				() -> new Appointment("113242143124321432143214214", currentDatePlusOne, "dentist"));
	}

	@Test
	public void testAppointmentIdNull() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();
		assertThrows(IllegalArgumentException.class, () -> new Appointment(null, currentDatePlusOne, "dentist"));
	}

	@Test
	public void testDatePast() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, -1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//    c.add(Calendar.HOUR, 1);
//    c.add(Calendar.MINUTE, 1);
//    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePast = c.getTime();
		assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDatePast, "dentist"));
	}

	@Test
	public void testDateNull() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//	    c.add(Calendar.HOUR, 1);
//	    c.add(Calendar.MINUTE, 1);
//	    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();
		assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "dentist"));
	}

	@Test
	public void testDescriptionLength() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//	    c.add(Calendar.HOUR, 1);
//	    c.add(Calendar.MINUTE, 1);
//	    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();
		assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDatePlusOne,
				"dentisasdfdasfdasfadsfasdfdasfadsfadsfdsafsdhsadjf;lkadsj;kfljadsj;lfkjdasjfjdasklf;ljadskjfjsadl;kfjadslkjfkdaslfj;lkdsjft"));
	}

	@Test
	public void testDescriptionNull() {
		Date currentDate = new Date();
//		System.out.println(dateFormat.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
//    c.add(Calendar.YEAR, 1);
//    c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 1); // same with c.add(Calendar.DAY_OF_MONTH, 1);
//	    c.add(Calendar.HOUR, 1);
//	    c.add(Calendar.MINUTE, 1);
//	    c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();
		assertThrows(IllegalArgumentException.class, () -> new Appointment("1", currentDatePlusOne, null));
	}
}
