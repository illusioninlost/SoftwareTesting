package test;

import static org.junit.jupiter.api.Assertions.*;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;


import com.richardchang.Task;
import com.richardchang.TaskService;

/**
 * 
 * @author Richard Chang
 * @date 7/20/22
 *
 */
public class TaskServiceTest {

	// test addTask() method
	@Test
	void testAddTask() {
		TaskService ts = new TaskService();
		boolean bTest = ts.addTask("1233", "new name", "new description");
		assertEquals(true, bTest);

	}

	@Test
	void testAddTaskFail() {
		TaskService ts = new TaskService();
		ts.addTask("1233", "new name", "new description");
		boolean bTest = ts.addTask("1233", "new name", "new description");
		assertEquals(false, bTest);
	}

	// test deleteTask() method
	@Test
	void testDeleteTask() {
		TaskService ts = new TaskService();
		ts.addTask("1233", "new name", "new description");
		boolean bTest = ts.deleteTask("1233");
		assertEquals(true, bTest);
	}

	@Test
	void testDeleteTaskFail() {
		TaskService ts = new TaskService();
		boolean bTest = ts.deleteTask("1233");
		assertEquals(false, bTest);
	}

	// test updateTask() method
	@Test
	void testUpdateTask() {
		TaskService ts = new TaskService();
		ts.addTask("1233", "new name", "new description");
		boolean bTest = ts.updateTask("1233", "askldfjkjasdf","newer description");
		assertEquals(true, bTest);
	}

	@Test
	void testUpdateTaskFail() {
		TaskService ts = new TaskService();
		boolean bTest = ts.updateTask("1233", "askldfjkjasdf","newer description");
		assertEquals(false, bTest);
	}

}
